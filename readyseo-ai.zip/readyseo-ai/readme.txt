=== AI SEO ===
Contributors: readystudio, fazelghaemi
Tags: seo, ai, gemini, content, rank math, jetengine, vision, robots, robots.txt, artificial intelligence, سئو, هوش مصنوعی
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 13.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
افزونه نسل جدید سئو وردپرس با قدرت هوش مصنوعی. مجهز به مغز AI، تولید محتوا، تحلیل بصری و سازنده Robots.txt. محصولی از Ready Studio.
== Description ==
افزونه AI SEO فراتر از یک ابزار سئو است؛ این یک استراتژیست محتوا و دستیار فنی هوشمند برای سایت شماست.
آیا از صرف ساعت‌ها زمان برای نوشتن عنوان‌های جذاب، توضیحات متا، و محتوای بهینه خسته شده‌اید؟ افزونه AI SEO، محصولی از خانواده Ready Studio، این فرآیند را به چند ثانیه کاهش می‌دهد.
این افزونه با استفاده از معماری ماژولار و اتصال مستقیم به API قدرتمند Google Gemini (از طریق ورکر امن Cloudflare)، به شما اجازه می‌دهد تا نه تنها سئوی سایت خود را خودکار کنید، بلکه محتوای ضعیف (Thin Content) را شناسایی کرده و آن را با پاراگراف‌های توصیفی غنی‌سازی کنید.
امنیت کامل: برخلاف افزونه‌های دیگر، کلید API ارزشمند شما هرگز در دیتابیس وردپرس ذخیره نمی‌شود. تمام درخواست‌ها از طریق ورکر شخصی شما در Cloudflare عبور می‌کنند.
قابلیت‌های خارق‌العاده (Nexus Core v13)
🧠 مغز هوشمند AI (Nexus Brain):
به افزونه یاد بدهید چطور فکر کند! در بخش تنظیمات، می‌توانید "دانش پایه" (هویت برند، مخاطبان، و لحن نگارش سایت) و "قوانین سفارشی" (مانند "همیشه از هشتگ #ReadyPrompt استفاده کن") را به AI آموزش دهید.
✍️ ماژول سئو و تولید محتوا:
با یک کلیک در ویرایشگر پست، عنوان سئو، توضیحات متا، کلمات کلیدی کانونی (سازگار با Rank Math) و تگ‌های مرتبط بسازید. مهم‌تر از آن، مشکل "محتوای ضعیف" (Thin Content) را با تولید پاراگراف‌های توصیفی و غنی برای بدنه پست خود حل کنید.
👁️ ماژول تحلیل بصری (Gemini Vision):
اینجا جادو اتفاق می‌افتد. این ماژول به جای خواندن متن، مستقیماً به تصویر شاخص شما "نگاه" می‌کند. AI سبک هنری (مثلاً "سینمایی، ماکرو")، کلمات کلیدی بصری (مثلاً "سکه طلا، چوب تیره") و دقیق‌ترین متن جایگزین (Alt Text) ممکن را بر اساس آنچه واقعاً در تصویر می‌بیند، استخراج می‌کند.
🤖 ماژول سازنده Robots.txt هوشمند:
دیگر نگران خطای 404 یا تنظیمات پیچیده robots.txt نباشید. به سادگی با زبان فارسی به AI دستور دهید (مثلاً: "سایت را از دسترس همه بجز گوگل ببند") و AI بلافاصله قوانین حرفه‌ای را برای شما تولید می‌کند. این ماژول هم از حالت "مجازی" وردپرس و هم از "نوشتن فایل فیزیکی" (برای حل مشکل 404 سرورها) پشتیبانی می‌کند.
🚀 ماژول تولید انبوه (Bulk Generator):
تمام پست‌های قدیمی، محصولات، یا پست‌تایپ‌های سفارشی خود را با یک کلیک بهینه‌سازی کنید. در صف پردازش، انتخاب کنید که آیا سئو، محتوا، یا Alt تصاویر تولید شوند و پیشرفت کار را در "کنسول لاگ" زنده مشاهده کنید.
🎨 رابط کاربری "Soft UI" (طراحی نرم):
با الهام از جدیدترین استانداردهای UI/UX گوگل و بر اساس هویت بصری Ready Studio، ما یک رابط کاربری زیبا، مدرن، با گوشه‌های گرد و فونت سفارشی (یکان بخ) طراحی کرده‌ایم تا کار با افزونه لذت‌بخش باشد.
== Installation ==
راه‌اندازی این افزونه حرفه‌ای در ۳ مرحله ساده انجام می‌شود:
مرحله ۱: راه‌اندازی ورکر Cloudflare (اجباری)
به حساب Cloudflare خود بروید، یک Worker جدید بسازید.
کد کامل زیر را در ویرایشگر ورکر کپی و ذخیره (Save and Deploy) کنید:
<pre>
export default {
async fetch(request, env, ctx) {
if (request.method !== "POST") {
return new Response(JSON.stringify({ error: { message: "Expected POST request" } }), {
status: 405,
headers: { "Content-Type": "application/json" }
});
}
try {
const data = await request.json();
const { api_key, model_name, action_type } = data;
if (!api_key || !model_name) {
return new Response(JSON.stringify({ error: { message: "Missing API Key or Model Name" } }), {
status: 400,
headers: { "Content-Type": "application/json" }
});
}
let geminiUrl;
let payload;
if (action_type === 'vision') {
geminiUrl = https://generativelanguage.googleapis.com/v1beta/models/${model_name}:generateContent?key=${api_key};
const { system_prompt, image_data, mime_type } = data;
payload = {
contents: [{
parts: [
{ text: system_prompt },
{ inlineData: { mimeType: mime_type, data: image_data } }
]
}],
generationConfig: { responseMimeType: "application/json" }
};
} else {
geminiUrl = https://generativelanguage.googleapis.com/v1beta/models/${model_name}:generateContent?key=${api_key};
const { contents, generationConfig } = data;
payload = {
contents: contents,
generationConfig: generationConfig
};
}
const geminiResponse = await fetch(geminiUrl, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify(payload)
});
const geminiData = await geminiResponse.json();
if (!geminiResponse.ok) {
throw new Error(geminiData.error.message || "Unknown Gemini API error");
}
return new Response(JSON.stringify(geminiData), {
headers: { "Content-Type": "application/json" }
});
} catch (error) {
return new Response(JSON.stringify({ error: { message: error.message } }), {
status: 500,
headers: { "Content-Type": "application/json" }
});
}
}
};
</pre>
3. آدرس ورکر ساخته شده (مثلاً https://my-worker.example.workers.dev) را کپی کنید.
مرحله ۲: نصب و تنظیم افزونه
پوشه ready-seo را در wp-content/plugins/ آپلود و افزونه را فعال کنید.
به منوی جدید "Ready Studio" در پیشخوان وردپرس بروید.
در تب "اتصال (API)"، آدرس ورکر (از مرحله ۱) و کلید API گوگل Gemini خود را وارد کنید.
دکمه "تست ارتباط با ورکر" را بزنید.
اگر پیام "✓ ارتباط موفقیت‌آمیز بود!" را دیدید، افزونه آماده است.
مرحله ۳: (پیشنهادی) آموزش "مغز هوش مصنوعی"
به تب "مغز هوش مصنوعی (AI Brain)" بروید.
در بخش "دانش پایه"، سایت خود را به AI معرفی کنید (مثال: "ما یک سایت فروشگاهی قهوه هستیم...").
در بخش "پرامپت سفارشی"، قوانین خود را بنویسید (مثال: "همیشه در تگ‌ها کلمه 'قهوه' را بگنجان.").
تنظیمات را ذخیره کنید. هوش مصنوعی اکنون طبق هویت برند شما محتوا تولید می‌کند.
== Frequently Asked Questions ==
= آیا به افزونه Rank Math یا Yoast نیاز دارم؟ =
خیر. افزونه AI SEO به تنهایی کار می‌کند. اما اگر Rank Math یا Yoast نصب باشند، افزونه ما به طور خودکار فیلدهای آن‌ها (کلمه کلیدی، عنوان، متا) را پر می‌کند و با آن‌ها کاملاً یکپارچه است.
= چرا دکمه "تست ارتباط" خطای "Missing API Key" می‌دهد؟ =
این خطا از طرف ورکر کلودفلر می‌آید و به این معناست که شما "کلید API (Gemini)" را در فیلد مربوطه در صفحه تنظیمات افزونه وارد نکرده‌اید.
= چرا دکمه "تست ارتباط" خطای "Error: 404" یا "API Key not valid" می‌دهد؟ =
این خطا از طرف گوگل می‌آید. به این معناست که کلید API شما صحیح است، اما مدل انتخابی (مثلاً gemini-2.0-flash) برای اکانت شما فعال نیست.
راه حل: مدل هوش مصنوعی را به gemini-1.5-pro تغییر دهید و مجدداً تست کنید.
= چرا دکمه "تست ارتباط" خطای "✗ خطای سرور. (AJAX Fail)" می‌دهد؟ =
این یک خطای 403 یا 500 از طرف سرور وردپرس شماست. معمولاً به این دلیل است که یک افزونه امنیتی (مثل Wordfence) یا فایروال هاست شما (ModSecurity)، دسترسی به admin-ajax.php را مسدود کرده است.
راه حل: در افزونه امنیتی خود، admin-ajax.php را در "لیست سفید" (Whitelist) قرار دهید.
= چرا متاباکس AI SEO در صفحه ویرایش پست خالی است (فقط دکمه ذخیره دارد)؟ =
این خطا به این معناست که فایل‌های ماژول افزونه به درستی بارگذاری نشده‌اند.
راه حل: افزونه را به طور کامل حذف و مجدداً نصب کنید. مطمئن شوید که پوشه modules و تمام فایل‌های PHP داخل آن (class-rs-module-seo.php، class-rs-module-content.php و class-rs-module-vision.php) به درستی در هاست شما کپی شده‌اند.
= چرا آدرس yoursite.com/robots.txt خطای 404 می‌دهد؟ =
سرور شما (معمولاً nginx) به دنبال یک فایل فیزیکی می‌گردد.
راه حل: به "Ready Studio -> سازنده Robots.txt" بروید. پس از تولید قوانین، دکمه مشکی "نوشتن فایل فیزیکی در هاست" را بزنید تا افزونه فایل را مستقیماً در ریشه هاست شما ایجاد کند.
== Screenshots ==
صفحه تنظیمات اصلی (اتصال API و مغز هوشمند AI).
متاباکس در ویرایشگر پست (نمایش هر سه تب: سئو، محتوا، و تحلیل بصری).
صفحه تولید انبوه (Bulk Generator) همراه با کنسول لاگ.
ماژول سازنده Robots.txt (نمایش پرامپت سفارشی و پیش‌نمایش زنده).
نتیجه نهایی (پر شدن خودکار فیلدهای افزونه Rank Math).
== Changelog ==
= 13.2.0 (Soft UI) =
MAJOR UIX: بازنویسی کامل style-core.css و style-metabox.css بر اساس UI/UX "نرم و گرد".
NEW: اعمال فونت سفارشی (یکان بخ - readyfont.woff) در تمام بخش‌های افزونه.
= 13.1.0 =
NEW: اضافه شدن ماژول "راهنما و آموزش" (همین صفحه) به صورت داینامیک.
FIX: بازنویسی بخش عیب‌یابی برای مشتریان نهایی.
NEW: جاسازی کد ورکر به جای لینک به گیت‌هاب.
FIX: حذف ارجاعات به CPT خاص (prompts) برای عمومی‌سازی افزونه.
= 13.0.0 =
FIX: رفع کامل خطای فاجعه‌بار Parse Error در ماژول Robots.txt با بازنویسی تابع get_task_prompt.
= 12.9.0 =
NEW: اضافه شدن فیلد "پرامپت سفارشی" (دستور با زبان فارسی) به ماژول Robots.txt.
FIX: آپدیت admin-core.js برای پشتیبانی از پرامپت سفارشی.
= 12.8.0 =
NEW: اضافه شدن قابلیت "نوشتن فایل فیزیکی robots.txt" برای حل مشکل 404 سرورها.
NEW: اضافه شدن بررسی سطح دسترسی (Permissions) هاست.
= 12.7.0 =
FIX: اصلاح پرامپت AI در ماژول Robots.txt برای تولید قوانین حرفه‌ای و امن (بستن plugins و themes).
= 12.6.0 =
FIX: رفع خطای Fatal Error مربوط به بارگذاری منوی Robots.txt قبل از بارگذاری ماژول.
= 12.5.0 =
FIX: رفع خطای Fatal Error (عدم نمایش متاباکس) با اصلاح __construct در هر سه ماژول (SEO, Content, Vision).
FIX: رفع خطای Fatal Error (کلاس ReadyStudio_Module_SEO یافت نشد) در "تولید انبوه" با افزودن class_exists.
= 12.4.0 =
FIX: رفع خطای "AJAX Fail" و "Unknown worker error" در دکمه "تست ارتباط" با اصلاح worker.js و class-rs-core-api.php.
= 12.3.0 =
NEW: اضافه شدن مجدد دکمه "تست ارتباط" به تنظیمات.
FIX: رفع خطای Fatal Error (عدم تزریق API به Settings).
FIX: رفع مشکل "منوی تکراری" در پیشخوان وردپرس.
= 12.1.0 =
NEW: اعمال کامل برندینگ "AI SEO" (محصول Ready Studio) با رنگ‌های سازمانی (مشکی/سبز) و لوگوهای سفارشی.
NEW: بازنویسی کامل CSS برای UIX مدرن (دکمه‌های منحنی و قطور).
= 12.0.0 (Nexus Core) =
MAJOR: بازنویسی کامل معماری افزونه به "هسته ماژولار" (Core + Modules).
NEW: اضافه شدن ماژول تحلیل بصری (Vision).
NEW: ارتقای ورکر کلودفلر برای پردازش همزمان متن و تصویر.
NEW: تفکیک تمام فایل‌های PHP و CSS به کلاس‌های مجزا.
= 10.0.0 =
FIX: رفع نهایی خطای فاجعه‌بار Parse Error (کلاس تکراری).
= 1.
